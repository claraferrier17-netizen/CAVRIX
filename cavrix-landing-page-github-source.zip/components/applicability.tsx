import { ArrowRight, GitBranch } from "lucide-react";
import { CtaLink } from "@/components/cta-link";
import { SectionHeader } from "@/components/section-header";
import { SourceRef } from "@/components/source-ref";
import { applicabilitySteps, evidenceItems } from "@/lib/content";
import { contactUrl } from "@/lib/links";

export function Applicability() {
  return (
    <section id="applicability" className="border-y border-line bg-ink py-24 md:py-32">
      <div className="section-shell">
        <div className="grid overflow-hidden rounded-lg border border-line bg-paper text-ink md:grid-cols-2 xl:grid-cols-4">
          {evidenceItems.map((item) => (
            <article key={item.label} className="border-b border-ink/10 p-6 md:border-r xl:border-b-0">
              <p className="font-mono text-[0.68rem] font-black uppercase tracking-[0.14em] text-ink/58">
                {item.label}
              </p>
              <p className="mt-3 text-3xl font-semibold tracking-normal text-ink">{item.value}</p>
              <p className="mt-3 text-sm leading-6 text-ink/72">
                {item.text}
                <SourceRef id={item.source} />
              </p>
            </article>
          ))}
        </div>

        <div className="mt-14 grid gap-12 lg:grid-cols-[0.86fr_1.14fr] lg:items-start">
        <div>
          <SectionHeader
            eyebrow="Could NIS2 apply to your company?"
            title="Machinery manufacturing is a listed sector under the German BSI Act."
          />
          <div className="mt-7 space-y-5 text-base leading-7 text-muted md:text-lg">
            <p>
              The manufacture of machinery and equipment is listed in Annex 2 of the German BSI
              Act as a sector for important entities.
              <SourceRef id={5} />
            </p>
            <p>
              A company carrying out a listed machinery-manufacturing activity may fall within scope
              if it employs at least 50 people, or if both annual turnover and annual balance-sheet
              total exceed €10 million. Exact classification may also depend on entity and group
              calculations, specific activities and statutory exceptions.
              <SourceRef id={6} />
            </p>
            <p>
              Companies must assess their individual status. An individual assessment is required
              before deciding what needs to be implemented.
            </p>
          </div>
          <div className="mt-8">
            <CtaLink
              href={contactUrl("applicability")}
              location="applicability"
              label="Check your likely applicability"
              className="w-full sm:w-auto"
            >
              Check your likely applicability
              <ArrowRight aria-hidden="true" className="h-4 w-4" />
            </CtaLink>
            <p className="mt-4 text-sm leading-6 text-muted">
              Establish the facts before deciding what needs to be implemented.
            </p>
          </div>
        </div>

        <div className="relative rounded-lg border border-line bg-raised p-4 shadow-panel sm:p-6">
          <div aria-hidden="true" className="absolute inset-0 technical-grid opacity-35" />
          <div className="relative">
            <div className="mb-5 flex items-center gap-3">
              <span className="inline-flex h-10 w-10 items-center justify-center rounded-md border border-accent/35 bg-accent/10 text-accent">
                <GitBranch aria-hidden="true" className="h-5 w-5" />
              </span>
              <div>
                <p className="font-mono text-[0.68rem] font-bold uppercase tracking-[0.16em] text-muted">
                  Connected criteria
                </p>
                <p className="text-sm text-paper">No single checkbox gives the final answer.</p>
              </div>
            </div>
            <ol className="grid gap-3">
              {applicabilitySteps.map((step, index) => (
                <li key={step} className="grid grid-cols-[auto_1fr] items-center gap-4">
                  <span className="flex h-9 w-9 items-center justify-center rounded-full border border-line bg-ink font-mono text-xs font-bold text-accent">
                    {index + 1}
                  </span>
                  <div className="relative rounded-md border border-line bg-ink/70 px-4 py-4">
                    {index < applicabilitySteps.length - 1 ? (
                      <span
                        aria-hidden="true"
                        className="absolute -bottom-4 left-[-2.05rem] h-4 w-px bg-line"
                      />
                    ) : null}
                    <p className="font-semibold text-paper">{step}</p>
                  </div>
                </li>
              ))}
            </ol>
            <p className="mt-5 rounded-md border border-line bg-ink/70 p-4 text-sm leading-6 text-muted">
              Meeting one indicator does not by itself establish a definitive legal classification.
            </p>
          </div>
        </div>
      </div>
      </div>
    </section>
  );
}
