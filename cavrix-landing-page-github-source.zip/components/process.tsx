import { ArrowRight } from "lucide-react";
import { CtaLink } from "@/components/cta-link";
import { SectionHeader } from "@/components/section-header";
import { processStages } from "@/lib/content";
import { contactUrl } from "@/lib/links";

export function Process() {
  return (
    <section id="how-it-works" className="border-y border-line bg-ink py-24 md:py-32">
      <div className="section-shell">
        <SectionHeader
          eyebrow="From uncertainty to an operating plan"
          title="Start with the facts. Then close the gaps."
        />

        <div className="relative mt-12 grid gap-4 lg:grid-cols-4">
          <span
            aria-hidden="true"
            className="absolute left-0 right-0 top-12 hidden h-px bg-line lg:block"
          />
          {processStages.map((stage) => (
            <article key={stage.number} className="relative rounded-lg border border-line bg-raised p-6">
              <span className="inline-flex h-12 w-12 items-center justify-center rounded-full border border-accent/35 bg-ink font-mono text-sm font-black text-accent">
                {stage.number}
              </span>
              <h3 className="mt-6 text-xl font-semibold leading-tight text-paper">{stage.title}</h3>
              <p className="mt-4 text-sm leading-6 text-muted">{stage.text}</p>
              <div className="mt-6 rounded-md border border-line bg-ink/70 p-4">
                <p className="font-mono text-[0.64rem] font-bold uppercase tracking-[0.14em] text-muted">
                  Output
                </p>
                <p className="mt-2 text-sm font-semibold leading-5 text-paper">{stage.output}</p>
              </div>
            </article>
          ))}
        </div>

        <div className="mt-10">
          <CtaLink
            href={contactUrl("process")}
            location="process"
            label="Start with a free assessment"
            className="w-full sm:w-auto"
          >
            Start with a free assessment
            <ArrowRight aria-hidden="true" className="h-4 w-4" />
          </CtaLink>
        </div>
      </div>
    </section>
  );
}
