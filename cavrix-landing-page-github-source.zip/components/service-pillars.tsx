import { ArrowRight, Check } from "lucide-react";
import { CtaLink } from "@/components/cta-link";
import { SectionHeader } from "@/components/section-header";
import { servicePillars } from "@/lib/content";
import { contactUrl } from "@/lib/links";

export function ServicePillars() {
  return (
    <section id="why-cavrix" className="border-y border-line bg-ink py-24 md:py-32">
      <div className="section-shell">
        <div className="grid gap-10 lg:grid-cols-[0.82fr_1.18fr] lg:items-end">
          <SectionHeader
            eyebrow="One accountable operating model"
            title="Run the IT. Reduce the risk. Maintain the evidence."
            copy="CAVRIX brings the three parts of the problem together through one partner and one coordinated operating model."
          />
          <p className="max-w-2xl text-base leading-7 text-muted lg:justify-self-end">
            Instead of treating compliance as a separate documentation exercise, CAVRIX connects it
            to the systems, responsibilities and security work behind it.
          </p>
        </div>

        <div className="mt-12 grid gap-4 lg:grid-cols-3">
          {servicePillars.map((pillar, index) => (
            <article
              key={pillar.label}
              className={`rounded-lg border bg-raised p-6 shadow-panel ${
                index === 1 ? "border-accent/35" : "border-line"
              }`}
            >
              <p className="font-mono text-[0.7rem] font-black uppercase tracking-[0.14em] text-accent">
                {pillar.label}
              </p>
              <h3 className="mt-4 min-h-[4rem] text-xl font-semibold leading-tight text-paper">
                {pillar.headline}
              </h3>
              <ul className="mt-6 grid gap-3">
                {pillar.items.map((item) => (
                  <li key={item} className="flex items-start gap-3 text-sm leading-6 text-muted">
                    <Check aria-hidden="true" className="mt-1 h-4 w-4 shrink-0 text-accent" />
                    <span>{item}</span>
                  </li>
                ))}
              </ul>
            </article>
          ))}
        </div>

        <div className="mt-10">
          <CtaLink
            href={contactUrl("services")}
            location="services"
            label="Discuss your current setup"
            variant="secondary"
            className="w-full sm:w-auto"
          >
            Discuss your current setup
            <ArrowRight aria-hidden="true" className="h-4 w-4" />
          </CtaLink>
        </div>
      </div>
    </section>
  );
}
