import { ExternalLink } from "@/components/external-link";
import { additionalResources, sources } from "@/lib/sources";

export function SourceNotes() {
  return (
    <section id="sources" className="bg-graphite py-24 md:py-32">
      <div className="section-shell">
        <details open className="rounded-lg border border-line bg-ink/72 p-5 shadow-panel sm:p-7">
          <summary className="cursor-pointer rounded-sm text-2xl font-semibold text-paper focus-visible:outline-none focus-visible:ring-2 focus-visible:ring-accent focus-visible:ring-offset-2 focus-visible:ring-offset-ink">
            Sources and legal information
          </summary>
          <div className="mt-8 grid gap-4">
            {sources.map((source) => (
              <article
                key={source.id}
                id={`source-${source.id}`}
                className="scroll-mt-36 rounded-md border border-line bg-white/[0.035] p-4"
              >
                <p className="font-mono text-xs font-black uppercase tracking-[0.14em] text-accent">
                  Source {source.id}
                </p>
                <h3 className="mt-2 text-lg font-semibold text-paper">{source.title}</h3>
                <p className="mt-2 text-sm leading-6 text-muted">{source.description}</p>
                <ul className="mt-4 grid gap-2">
                  {source.urls.map((url) => (
                    <li key={url.href}>
                      <ExternalLink
                        href={url.href}
                        className="inline-flex items-center gap-1.5 rounded-sm text-sm font-semibold text-paper underline decoration-white/25 underline-offset-4 transition hover:text-accent hover:decoration-accent"
                      >
                        {url.label}
                      </ExternalLink>
                    </li>
                  ))}
                </ul>
              </article>
            ))}
          </div>

          <div className="mt-5 rounded-md border border-line bg-white/[0.035] p-4">
            <p className="font-mono text-xs font-black uppercase tracking-[0.14em] text-muted">
              Additional resource
            </p>
            <ul className="mt-3">
              {additionalResources.map((resource) => (
                <li key={resource.href}>
                  <ExternalLink
                    href={resource.href}
                    className="inline-flex items-center gap-1.5 rounded-sm text-sm font-semibold text-paper underline decoration-white/25 underline-offset-4 transition hover:text-accent hover:decoration-accent"
                  >
                    {resource.label}
                  </ExternalLink>
                </li>
              ))}
            </ul>
          </div>

          <div className="mt-5 rounded-md border border-accent/24 bg-accent/10 p-4">
            <p className="text-sm leading-7 text-paper">
              The information on this page provides a general overview and does not constitute legal
              advice. Whether NIS2 and the German BSI Act apply to a particular organisation depends
              on its individual circumstances and should be assessed using the current statutory
              requirements and, where necessary, qualified legal advice.
            </p>
            <p className="mt-4 font-mono text-xs font-bold uppercase tracking-[0.14em] text-muted">
              Sources last reviewed: 11 July 2026
            </p>
          </div>
        </details>
      </div>
    </section>
  );
}
