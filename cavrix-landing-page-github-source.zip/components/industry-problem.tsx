import { AlertTriangle, ArrowRight } from "lucide-react";
import { SectionHeader } from "@/components/section-header";
import { industryRisks } from "@/lib/content";

const flow = [
  "Identity",
  "Workplace IT",
  "Business systems",
  "Production support",
  "Suppliers",
  "Customers",
] as const;

export function IndustryProblem() {
  return (
    <section className="bg-graphite py-24 md:py-32">
      <div className="section-shell">
        <SectionHeader
          eyebrow="When cyber risk becomes production risk"
          title="Your production depends on more than machines."
          copy="Modern machinery manufacturers depend on connected business systems, employee identities, remote access, suppliers, service providers, backups and production-supporting infrastructure. A compromised account, unpatched endpoint or unavailable server can quickly become an operational problem."
        />

        <div className="mt-12 overflow-hidden rounded-lg border border-line bg-ink/72">
          <div className="grid divide-y divide-line lg:grid-cols-6 lg:divide-x lg:divide-y-0">
            {flow.map((item, index) => (
              <div key={item} className="relative p-5">
                <p className="font-mono text-[0.68rem] font-bold uppercase tracking-[0.14em] text-accent/80">
                  {String(index + 1).padStart(2, "0")}
                </p>
                <p className="mt-3 text-sm font-semibold text-paper">{item}</p>
                {index < flow.length - 1 ? (
                  <ArrowRight
                    aria-hidden="true"
                    className="absolute right-4 top-5 hidden h-4 w-4 text-muted lg:block"
                  />
                ) : null}
              </div>
            ))}
          </div>
        </div>

        <div className="mt-8 grid gap-3 sm:grid-cols-2 lg:grid-cols-3">
          {industryRisks.map((risk) => (
            <div key={risk} className="flex items-start gap-3 rounded-md border border-line bg-white/[0.035] p-4">
              <AlertTriangle aria-hidden="true" className="mt-0.5 h-4 w-4 shrink-0 text-accent" />
              <p className="text-sm leading-6 text-paper">{risk}</p>
            </div>
          ))}
        </div>

        <p className="mt-8 max-w-4xl text-base leading-8 text-muted md:text-lg">
          Responsibility is often divided between an IT provider, individual security tools and
          external compliance consultants. Each sees only part of the environment. Management is
          left without one reliable view of what is protected, what remains open and what can be
          demonstrated.
        </p>
      </div>
    </section>
  );
}
