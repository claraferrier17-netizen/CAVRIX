import { ExternalLinkIcon } from "lucide-react";

type ExternalLinkProps = {
  href: string;
  children: React.ReactNode;
  className?: string;
};

export function ExternalLink({ href, children, className }: ExternalLinkProps) {
  return (
    <a
      href={href}
      target="_blank"
      rel="noopener noreferrer"
      className={className}
    >
      <span>{children}</span>
      <ExternalLinkIcon aria-hidden="true" className="inline h-3.5 w-3.5 translate-y-[-1px]" />
    </a>
  );
}
