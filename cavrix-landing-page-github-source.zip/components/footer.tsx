import { ExternalLink } from "@/components/external-link";
import { footerGroups } from "@/lib/links";

export function Footer() {
  return (
    <footer className="border-t border-line bg-graphite py-14">
      <div className="section-shell">
        <div className="grid gap-10 lg:grid-cols-[0.9fr_1.1fr]">
          <div>
            <p className="font-mono text-lg font-black tracking-[0.24em] text-paper">
              CAVRI<span className="text-accent">X</span>
            </p>
            <p className="mt-4 max-w-sm text-sm leading-6 text-muted">
              We run your IT, security and compliance.
            </p>
            <a
              href="mailto:info@cavrix.de"
              className="mt-5 inline-flex rounded-sm text-sm font-semibold text-paper underline decoration-white/25 underline-offset-4 hover:text-accent hover:decoration-accent"
            >
              info@cavrix.de
            </a>
          </div>
          <div className="grid gap-8 sm:grid-cols-2 lg:grid-cols-4">
            {footerGroups.map((group) => (
              <div key={group.title}>
                <h2 className="font-mono text-[0.7rem] font-black uppercase tracking-[0.14em] text-muted">
                  {group.title}
                </h2>
                <ul className="mt-4 grid gap-3">
                  {group.links.map((link) => (
                    <li key={link.href}>
                      <ExternalLink
                        href={link.href}
                        className="inline-flex items-center gap-1.5 rounded-sm text-sm text-paper/82 transition hover:text-accent"
                      >
                        {link.label}
                      </ExternalLink>
                    </li>
                  ))}
                </ul>
              </div>
            ))}
          </div>
        </div>
        <div className="mt-12 border-t border-line pt-6 text-sm text-muted">
          © 2026 CAVRIX, a brand of CITO GmbH. Built in Hamburg. Operated in the EU.
        </div>
      </div>
    </footer>
  );
}
