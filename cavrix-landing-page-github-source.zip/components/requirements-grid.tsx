import { ShieldCheck } from "lucide-react";
import { requirements } from "@/lib/content";
import { SectionHeader } from "@/components/section-header";
import { SourceRef } from "@/components/source-ref";

export function RequirementsGrid() {
  return (
    <section id="requirements" className="bg-graphite py-24 md:py-32">
      <div className="section-shell">
        <SectionHeader
          eyebrow="More than a policy document"
          title="NIS2 is an ongoing operating requirement, not a one-time certificate."
        />
        <p className="mt-6 max-w-3xl text-base leading-7 text-muted md:text-lg">
          Covered organisations must implement appropriate, proportionate and effective technical
          and organisational measures. These measures include the following areas.
          <SourceRef id={7} />
        </p>

        <div className="mt-12 grid gap-4 md:grid-cols-2 lg:grid-cols-3">
          {requirements.map((requirement) => (
            <article key={requirement.title} className="rounded-lg border border-line bg-ink/68 p-6">
              <ShieldCheck aria-hidden="true" className="h-5 w-5 text-accent" />
              <h3 className="mt-5 text-lg font-semibold text-paper">{requirement.title}</h3>
              <p className="mt-3 text-sm leading-6 text-muted">{requirement.text}</p>
            </article>
          ))}
          <article className="rounded-lg border border-accent/35 bg-accent/10 p-6 md:col-span-2 lg:col-span-3">
            <div className="flex flex-col gap-4 sm:flex-row sm:items-start">
              <ShieldCheck aria-hidden="true" className="h-5 w-5 shrink-0 text-accent" />
              <div>
                <h3 className="text-lg font-semibold text-paper">Control effectiveness</h3>
                <p className="mt-3 max-w-4xl text-sm leading-6 text-muted">
                  Processes for assessing whether cybersecurity measures are operating effectively,
                  not merely whether they have been documented.
                </p>
              </div>
            </div>
          </article>
        </div>

        <p className="mt-8 max-w-4xl text-base leading-8 text-muted md:text-lg">
          The challenge is not simply knowing that these requirements exist. It is assigning
          ownership, implementing them across the organisation and keeping the supporting evidence
          current.
        </p>
      </div>
    </section>
  );
}
