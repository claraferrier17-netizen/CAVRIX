export function SourceRef({ id }: { id: number }) {
  return (
    <sup className="source-ref">
      <a href={`#source-${id}`} aria-label={`Source ${id}`}>
        {id}
      </a>
    </sup>
  );
}
