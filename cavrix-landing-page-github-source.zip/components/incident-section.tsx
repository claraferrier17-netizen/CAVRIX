import { ArrowRight, ClipboardCheck } from "lucide-react";
import { CtaLink } from "@/components/cta-link";
import { SectionHeader } from "@/components/section-header";
import { SourceRef } from "@/components/source-ref";
import { incidentTimeline, managementQuestions } from "@/lib/content";
import { contactUrl } from "@/lib/links";

export function IncidentSection() {
  return (
    <section className="relative overflow-hidden border-y border-line bg-ink py-24 md:py-32">
      <div aria-hidden="true" className="absolute inset-0 technical-grid opacity-25" />
      <div className="section-shell relative">
        <div className="grid gap-12 lg:grid-cols-[0.9fr_1.1fr] lg:items-start">
          <div>
            <SectionHeader
              eyebrow="Management and incident readiness"
              title="You can delegate the work. You still need visibility."
            />
            <div className="mt-7 space-y-5 text-base leading-7 text-muted md:text-lg">
              <p>
                For covered entities, management bodies must implement the cybersecurity
                risk-management measures required under §30 BSIG, monitor their implementation and
                regularly participate in relevant training.
                <SourceRef id={4} />
              </p>
              <p>
                That requires clear ownership before a serious incident occurs, not a technical
                report once a year.
              </p>
              <p>
                CAVRIX translates technical activity into responsibilities, priorities and evidence
                that management can understand.
              </p>
            </div>
            <div className="mt-8">
              <CtaLink
                href={contactUrl("management")}
                location="management"
                label="Get a clearer view of your current position"
                variant="secondary"
                className="w-full sm:w-auto"
              >
                Get a clearer view of your current position
                <ArrowRight aria-hidden="true" className="h-4 w-4" />
              </CtaLink>
            </div>
          </div>

          <div className="rounded-lg border border-line bg-raised/82 p-5 shadow-panel sm:p-6">
            <div className="mb-5 flex items-center gap-3">
              <span className="inline-flex h-10 w-10 items-center justify-center rounded-md border border-accent/35 bg-accent/10 text-accent">
                <ClipboardCheck aria-hidden="true" className="h-5 w-5" />
              </span>
              <p className="font-mono text-[0.7rem] font-bold uppercase tracking-[0.16em] text-muted">
                Management questions
              </p>
            </div>
            <div className="grid gap-3 sm:grid-cols-2">
              {managementQuestions.map((question) => (
                <div key={question} className="rounded-md border border-line bg-white/[0.035] p-4">
                  <p className="text-sm font-semibold leading-6 text-paper">{question}</p>
                </div>
              ))}
            </div>
          </div>
        </div>

        <div className="mt-16">
          <p className="eyebrow">Preparation matters before an incident</p>
          <h3 className="mt-4 max-w-4xl text-3xl font-semibold leading-[1.06] text-paper md:text-5xl">
            Twenty-four hours is not the time to design your response process.
          </h3>
          <p className="mt-6 max-w-3xl text-base leading-7 text-muted md:text-lg">
            A significant cybersecurity incident may trigger staged reporting obligations.
            <SourceRef id={3} />
          </p>

          <div className="mt-10 grid gap-4 md:grid-cols-3">
            {incidentTimeline.map((item, index) => (
              <article key={item.label} className="relative rounded-lg border border-line bg-raised p-6">
                {index !== incidentTimeline.length - 1 ? (
                  <span
                    aria-hidden="true"
                    className="absolute left-[calc(100%-0.5rem)] top-1/2 hidden h-px w-8 bg-accent/40 md:block"
                  />
                ) : null}
                <p className="font-mono text-[0.68rem] font-black uppercase tracking-[0.12em] text-accent">
                  {item.label}
                </p>
                <h4 className="mt-5 text-2xl font-semibold text-paper">{item.text}</h4>
              </article>
            ))}
          </div>

          <div className="mt-8 max-w-4xl space-y-5 text-base leading-8 text-muted md:text-lg">
            <p>
              If the incident is still ongoing, a progress report may be required first, followed by
              the final report after the incident has been handled.
            </p>
            <p>
              Meeting these deadlines requires clear detection and escalation criteria, named
              decision-makers, reliable technical information, documented actions and an established
              communication process.
            </p>
            <p className="font-semibold text-paper">The process must exist before it is needed.</p>
          </div>
        </div>
      </div>
    </section>
  );
}
