import { ArrowRight, CheckCircle2 } from "lucide-react";
import { CtaLink } from "@/components/cta-link";
import { SystemMap } from "@/components/system-map";
import { contactUrl } from "@/lib/links";

const outputs = [
  "Likely NIS2 applicability",
  "Priority gaps to investigate",
  "A practical next-step recommendation",
] as const;

export function Hero() {
  return (
    <section id="top" className="relative overflow-hidden pt-36 md:pt-40">
      <div
        aria-hidden="true"
        className="absolute inset-x-0 top-0 h-[46rem] bg-[linear-gradient(130deg,rgba(255,255,255,0.08),transparent_36%),radial-gradient(circle_at_72%_22%,rgba(200,255,69,0.16),transparent_20rem)]"
      />
      <div className="section-shell relative grid min-h-[calc(100vh-7rem)] items-center gap-12 py-16 lg:grid-cols-[1.02fr_0.98fr] lg:gap-14 lg:py-20">
        <div className="reveal">
          <p className="eyebrow">Cybersecurity and NIS2 for German machinery manufacturers</p>
          <h1 className="mt-6 max-w-4xl text-5xl font-semibold leading-[0.98] tracking-normal text-paper md:text-7xl lg:text-8xl">
            Protect production.
            <span className="block text-accent">Make NIS2 implementation verifiable.</span>
          </h1>
          <p className="mt-7 max-w-2xl text-lg leading-8 text-muted md:text-xl">
            CAVRIX brings managed IT, cybersecurity and compliance evidence together for German
            machinery and equipment manufacturers without the cost and complexity of building an
            internal security and compliance department.
          </p>

          <div className="mt-9 flex flex-col gap-3 sm:flex-row">
            <CtaLink
              href={contactUrl("hero")}
              location="hero"
              label="Request a free NIS2 assessment"
              className="w-full sm:w-auto"
            >
              Request a free NIS2 assessment
              <ArrowRight aria-hidden="true" className="h-4 w-4" />
            </CtaLink>
            <a
              href="#why-cavrix"
              className="inline-flex min-h-12 w-full items-center justify-center rounded-md border border-line bg-white/[0.04] px-5 py-3 text-sm font-semibold text-paper transition hover:bg-white/[0.08] sm:w-auto"
            >
              See how CAVRIX works
            </a>
          </div>
          <p className="mt-4 font-mono text-xs font-semibold uppercase tracking-[0.14em] text-muted">
            Free · 30 minutes · No commitment
          </p>

          <div className="mt-8 grid gap-3 sm:grid-cols-3">
            {outputs.map((output) => (
              <div key={output} className="flex items-start gap-2 rounded-md border border-line bg-white/[0.035] p-3">
                <CheckCircle2 aria-hidden="true" className="mt-0.5 h-4 w-4 shrink-0 text-accent" />
                <p className="text-sm leading-5 text-paper">{output}</p>
              </div>
            ))}
          </div>
          <p className="mt-4 max-w-xl text-xs leading-5 text-muted">
            The initial assessment is not legal advice or an official certification.
          </p>
        </div>

        <div className="reveal lg:pt-8" style={{ animationDelay: "120ms" }}>
          <SystemMap />
        </div>
      </div>
    </section>
  );
}
