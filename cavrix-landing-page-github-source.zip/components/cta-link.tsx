"use client";

import Link from "next/link";
import type { CtaLocation } from "@/lib/links";

declare global {
  interface Window {
    dataLayer?: Array<Record<string, unknown>>;
  }
}

type CtaLinkProps = {
  href: string;
  location: CtaLocation;
  label: string;
  children?: React.ReactNode;
  className?: string;
  variant?: "primary" | "secondary" | "ghost";
  external?: boolean;
};

const variants = {
  primary:
    "bg-accent text-ink shadow-glow hover:bg-accentHover hover:shadow-[0_0_44px_rgba(200,255,69,0.28)]",
  secondary:
    "border border-line bg-white/[0.04] text-paper hover:border-white/24 hover:bg-white/[0.08]",
  ghost: "text-paper hover:bg-white/[0.07]",
};

export function CtaLink({
  href,
  location,
  label,
  children,
  className = "",
  variant = "primary",
  external = true,
}: CtaLinkProps) {
  const handleClick = () => {
    window.dataLayer?.push({
      event: "cavrix_cta_click",
      cta_location: location,
      cta_label: label,
      campaign: "nis2_machinery",
    });
  };

  const classes = [
    "inline-flex min-h-12 items-center justify-center gap-2 rounded-md px-5 py-3 text-sm font-semibold transition focus-visible:outline-none focus-visible:ring-2 focus-visible:ring-accent focus-visible:ring-offset-2 focus-visible:ring-offset-ink",
    variants[variant],
    className,
  ]
    .filter(Boolean)
    .join(" ");

  const content = children ?? label;

  if (external || href.startsWith("mailto:")) {
    return (
      <a
        href={href}
        onClick={handleClick}
        data-cta-location={location}
        className={classes}
        {...(href.startsWith("http") ? { target: "_blank", rel: "noopener noreferrer" } : {})}
      >
        {content}
      </a>
    );
  }

  return (
    <Link href={href} onClick={handleClick} data-cta-location={location} className={classes}>
      {content}
    </Link>
  );
}
