const nodes = [
  { label: "Identities", className: "left-[9%] top-[19%]" },
  { label: "Endpoints", className: "right-[10%] top-[18%]" },
  { label: "Business systems", className: "right-[5%] top-[47%]" },
  { label: "Recovery", className: "right-[14%] bottom-[11%]" },
  { label: "Suppliers", className: "left-[13%] bottom-[10%]" },
  { label: "Evidence", className: "left-[4%] top-[48%]" },
] as const;

export function SystemMap() {
  return (
    <div className="relative overflow-hidden rounded-lg border border-line bg-raised/86 p-4 shadow-panel sm:p-6">
      <div aria-hidden="true" className="absolute inset-0 technical-grid opacity-70" />
      <div
        aria-hidden="true"
        className="absolute inset-0 bg-[radial-gradient(circle_at_50%_45%,rgba(200,255,69,0.14),transparent_15rem)]"
      />
      <div className="relative">
        <div className="mb-4 flex flex-wrap items-center justify-between gap-3">
          <p className="font-mono text-[0.68rem] font-bold uppercase tracking-[0.18em] text-muted">
            Illustrative operating model
          </p>
          <div className="flex gap-2">
            {["Operate", "Protect", "Evidence"].map((label) => (
              <span
                key={label}
                className="rounded-sm border border-line bg-ink/60 px-2.5 py-1 font-mono text-[0.64rem] font-bold uppercase tracking-[0.12em] text-paper"
              >
                {label}
              </span>
            ))}
          </div>
        </div>

        <div className="relative mx-auto aspect-square w-full max-w-[520px]">
          <svg
            aria-hidden="true"
            className="absolute inset-0 h-full w-full"
            viewBox="0 0 520 520"
            fill="none"
          >
            <path d="M260 258L112 110" stroke="rgba(255,255,255,0.16)" strokeWidth="1.2" />
            <path d="M260 258L408 110" stroke="rgba(255,255,255,0.16)" strokeWidth="1.2" />
            <path d="M260 258L438 260" stroke="rgba(255,255,255,0.16)" strokeWidth="1.2" />
            <path d="M260 258L392 413" stroke="rgba(255,255,255,0.16)" strokeWidth="1.2" />
            <path d="M260 258L122 414" stroke="rgba(255,255,255,0.16)" strokeWidth="1.2" />
            <path d="M260 258L82 260" stroke="rgba(255,255,255,0.16)" strokeWidth="1.2" />
            <path d="M112 110C221 56 323 55 408 110" stroke="rgba(200,255,69,0.18)" strokeWidth="1" />
            <path d="M438 260C421 341 366 399 292 431" stroke="rgba(200,255,69,0.14)" strokeWidth="1" />
            <path d="M82 260C92 340 144 401 228 431" stroke="rgba(200,255,69,0.14)" strokeWidth="1" />
            <circle r="4" fill="#C8FF45" className="motion-signal">
              <animateMotion dur="8s" repeatCount="indefinite" path="M260 258L112 110" />
            </circle>
            <circle r="4" fill="#C8FF45" className="motion-signal" opacity="0.75">
              <animateMotion dur="9s" begin="-2s" repeatCount="indefinite" path="M260 258L438 260" />
            </circle>
            <circle r="4" fill="#C8FF45" className="motion-signal" opacity="0.65">
              <animateMotion dur="10s" begin="-4s" repeatCount="indefinite" path="M122 414L260 258L408 110" />
            </circle>
          </svg>

          <div className="absolute left-1/2 top-1/2 z-10 flex h-28 w-28 -translate-x-1/2 -translate-y-1/2 items-center justify-center rounded-full border border-accent/45 bg-ink/92 text-center shadow-glow sm:h-32 sm:w-32">
            <div>
              <p className="font-mono text-[0.64rem] uppercase tracking-[0.18em] text-muted">Partner</p>
              <p className="mt-1 font-mono text-lg font-black tracking-[0.22em] text-paper sm:text-xl">
                CAVRI<span className="text-accent">X</span>
              </p>
            </div>
          </div>

          {nodes.map((node) => (
            <div
              key={node.label}
              className={`absolute z-10 flex min-h-14 w-[6.9rem] items-center justify-center rounded-md border border-line bg-ink/84 px-2 text-center shadow-[0_10px_28px_rgba(0,0,0,0.24)] ${node.className}`}
            >
              <span className="text-[0.72rem] font-semibold leading-tight text-paper sm:text-sm">
                {node.label}
              </span>
            </div>
          ))}
        </div>
      </div>
    </div>
  );
}
