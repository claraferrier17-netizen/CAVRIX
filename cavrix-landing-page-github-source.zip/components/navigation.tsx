"use client";

import { ArrowRight, Menu, X } from "lucide-react";
import { useEffect, useState } from "react";
import { CtaLink } from "@/components/cta-link";
import { navItems } from "@/lib/content";
import { contactUrl } from "@/lib/links";

export function Navigation() {
  const [open, setOpen] = useState(false);
  const [scrolled, setScrolled] = useState(false);

  useEffect(() => {
    const onScroll = () => setScrolled(window.scrollY > 12);
    onScroll();
    window.addEventListener("scroll", onScroll, { passive: true });
    return () => window.removeEventListener("scroll", onScroll);
  }, []);

  useEffect(() => {
    document.body.style.overflow = open ? "hidden" : "";
    return () => {
      document.body.style.overflow = "";
    };
  }, [open]);

  const closeMenu = () => setOpen(false);

  return (
    <header
      className={`fixed inset-x-0 top-0 z-50 border-b transition ${
        scrolled || open
          ? "border-line bg-ink/92 shadow-[0_12px_40px_rgba(0,0,0,0.24)] backdrop-blur"
          : "border-white/[0.06] bg-ink/72 backdrop-blur-sm"
      }`}
    >
      <div className="border-b border-line bg-paper text-ink">
        <div className="section-shell flex min-h-9 flex-wrap items-center justify-center gap-x-2 gap-y-1 py-2 text-center text-xs font-semibold sm:justify-between sm:text-left">
          <span>NIS2 has been in force in Germany since 6 December 2025.</span>
          <a
            href="#applicability"
            onClick={closeMenu}
            className="inline-flex items-center gap-1 rounded-sm text-ink underline decoration-ink/30 underline-offset-4 hover:decoration-ink"
          >
            What this means for manufacturers <ArrowRight aria-hidden="true" className="h-3.5 w-3.5" />
          </a>
        </div>
      </div>
      <div className="section-shell flex h-20 items-center justify-between">
        <a
          href="#top"
          onClick={closeMenu}
          aria-label="CAVRIX home"
          className="rounded-sm font-mono text-base font-black tracking-[0.24em] text-paper"
        >
          CAVRI<span className="text-accent">X</span>
        </a>

        <nav aria-label="Primary navigation" className="hidden items-center gap-1 lg:flex">
          {navItems.map((item) => (
            <a
              key={item.href}
              href={item.href}
              className="rounded-md px-3 py-2 text-sm font-medium text-muted transition hover:bg-white/[0.06] hover:text-paper"
            >
              {item.label}
            </a>
          ))}
        </nav>

        <div className="hidden items-center gap-3 lg:flex">
          <CtaLink
            href={contactUrl("navigation")}
            location="navigation"
            label="Request an assessment"
            className="min-h-11 px-4 py-2"
          >
            Request an assessment
            <ArrowRight aria-hidden="true" className="h-4 w-4" />
          </CtaLink>
        </div>

        <button
          type="button"
          aria-label={open ? "Close menu" : "Open menu"}
          aria-expanded={open}
          onClick={() => setOpen((value) => !value)}
          className="inline-flex h-11 w-11 items-center justify-center rounded-md border border-line bg-white/[0.04] text-paper transition hover:bg-white/[0.08] lg:hidden"
        >
          {open ? <X aria-hidden="true" className="h-5 w-5" /> : <Menu aria-hidden="true" className="h-5 w-5" />}
        </button>
      </div>

      {open ? (
        <div className="border-t border-line bg-ink/96 lg:hidden">
          <nav aria-label="Mobile navigation" className="section-shell flex min-h-[calc(100vh-7rem)] flex-col py-6">
            <div className="grid gap-2">
              {navItems.map((item) => (
                <a
                  key={item.href}
                  href={item.href}
                  onClick={closeMenu}
                  className="rounded-md border border-line bg-white/[0.03] px-4 py-4 text-base font-semibold text-paper"
                >
                  {item.label}
                </a>
              ))}
            </div>
            <CtaLink
              href={contactUrl("navigation")}
              location="navigation"
              label="Request an assessment"
              className="mt-6 w-full"
            >
              Request an assessment
              <ArrowRight aria-hidden="true" className="h-4 w-4" />
            </CtaLink>
          </nav>
        </div>
      ) : null}
    </header>
  );
}
