type SectionHeaderProps = {
  eyebrow: string;
  title: string;
  copy?: string;
  align?: "left" | "center";
};

export function SectionHeader({ eyebrow, title, copy, align = "left" }: SectionHeaderProps) {
  return (
    <header className={align === "center" ? "mx-auto max-w-3xl text-center" : "max-w-3xl"}>
      <p className="eyebrow">{eyebrow}</p>
      <h2 className="mt-4 text-3xl font-semibold leading-[1.05] tracking-normal text-paper md:text-5xl">
        {title}
      </h2>
      {copy ? <p className="mt-5 text-base leading-7 text-muted md:text-lg">{copy}</p> : null}
    </header>
  );
}
