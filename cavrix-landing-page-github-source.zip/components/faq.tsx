"use client";

import { ArrowRight, ChevronDown, Mail } from "lucide-react";
import { type KeyboardEvent, useState } from "react";
import { CtaLink } from "@/components/cta-link";
import { SourceRef } from "@/components/source-ref";
import { faqItems } from "@/lib/content";
import { assessmentEmailUrl, contactUrl } from "@/lib/links";

const assessmentScope = [
  "likely NIS2 applicability",
  "the systems and processes most relevant to the assessment",
  "immediate implementation questions",
  "the appropriate next step for the organisation",
] as const;

export function Faq() {
  const [openIndex, setOpenIndex] = useState(0);

  const toggleIndex = (index: number) => {
    setOpenIndex((currentIndex) => (currentIndex === index ? -1 : index));
  };

  const handleQuestionKeyDown = (event: KeyboardEvent<HTMLButtonElement>, index: number) => {
    if (event.key !== "Enter" && event.key !== " ") {
      return;
    }

    event.preventDefault();
    toggleIndex(index);
  };

  return (
    <section aria-labelledby="faq-heading" className="border-y border-line bg-graphite py-24 md:py-32">
      <div className="section-shell">
        <div className="grid gap-10 lg:grid-cols-[0.38fr_0.62fr]">
          <header>
            <p className="eyebrow">Questions before the assessment</p>
            <h2 id="faq-heading" className="mt-4 text-3xl font-semibold leading-tight text-paper md:text-5xl">
              FAQ
            </h2>
          </header>
          <div className="divide-y divide-line rounded-lg border border-line bg-raised">
            {faqItems.map((item, index) => {
              const isOpen = openIndex === index;
              const panelId = `faq-panel-${index}`;
              return (
                <div key={item.question}>
                  <button
                    type="button"
                    aria-expanded={isOpen}
                    aria-controls={panelId}
                    onClick={() => toggleIndex(index)}
                    onKeyDown={(event) => handleQuestionKeyDown(event, index)}
                    className="flex w-full items-center justify-between gap-4 px-5 py-5 text-left text-base font-semibold text-paper transition hover:bg-white/[0.035] sm:px-6"
                  >
                    <span>{item.question}</span>
                    <ChevronDown
                      aria-hidden="true"
                      className={`h-5 w-5 shrink-0 text-accent transition ${isOpen ? "rotate-180" : ""}`}
                    />
                  </button>
                  <div id={panelId} hidden={!isOpen} className="px-5 pb-6 sm:px-6">
                    <p className="max-w-3xl text-sm leading-7 text-muted">
                      {item.answer}
                      {"source" in item && item.source ? <SourceRef id={item.source} /> : null}
                    </p>
                  </div>
                </div>
              );
            })}
          </div>
        </div>

        <div className="mt-16 relative overflow-hidden rounded-lg border border-accent/30 bg-ink p-6 shadow-glow sm:p-8 md:p-12">
          <div aria-hidden="true" className="absolute inset-0 technical-grid opacity-25" />
          <div className="relative grid gap-10 lg:grid-cols-[1fr_0.78fr] lg:items-end">
            <div>
              <p className="eyebrow">Start with clarity</p>
              <h3 className="mt-4 max-w-3xl text-3xl font-semibold leading-[1.04] text-paper md:text-6xl">
                Does NIS2 apply to your manufacturing business?
              </h3>
              <p className="mt-6 max-w-2xl text-lg leading-8 text-muted">
                Request a free initial assessment with CAVRIX.
              </p>
              <ul className="mt-7 grid gap-3 text-sm leading-6 text-muted sm:grid-cols-2">
                {assessmentScope.map((item) => (
                  <li key={item} className="rounded-md border border-line bg-white/[0.035] p-3">
                    {item}
                  </li>
                ))}
              </ul>
              <p className="mt-7 max-w-2xl text-base font-semibold leading-7 text-paper">
                No generic product demonstration. No commitment. A focused discussion about where
                your company is likely to stand.
              </p>
            </div>

            <div className="rounded-lg border border-line bg-raised/84 p-5">
              <CtaLink
                href={contactUrl("final")}
                location="final"
                label="Request a free NIS2 assessment"
                className="w-full"
              >
                Request a free NIS2 assessment
                <ArrowRight aria-hidden="true" className="h-4 w-4" />
              </CtaLink>
              <CtaLink
                href={assessmentEmailUrl}
                location="final_email"
                label="Email info@cavrix.de"
                variant="secondary"
                className="mt-3 w-full"
              >
                <Mail aria-hidden="true" className="h-4 w-4" />
                Email info@cavrix.de
              </CtaLink>
              <p className="mt-4 text-center font-mono text-xs font-semibold uppercase tracking-[0.14em] text-muted">
                30 minutes · Free · No sales pressure
              </p>
            </div>
          </div>
        </div>

        <div className="mx-auto mt-16 max-w-4xl text-center">
          <p className="eyebrow">CAVRIX for machinery manufacturers</p>
          <h3 className="mx-auto mt-5 max-w-4xl text-4xl font-semibold leading-[1.03] text-paper md:text-6xl">
            Protect production. Make implementation visible.
          </h3>
          <p className="mx-auto mt-6 max-w-2xl text-lg leading-8 text-muted">
            Bring IT operations, cybersecurity and NIS2 evidence into one accountable operating model.
          </p>
        </div>
      </div>
    </section>
  );
}
