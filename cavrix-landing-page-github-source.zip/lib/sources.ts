export type Source = {
  id: number;
  title: string;
  description: string;
  urls: { label: string; href: string }[];
};

export const sources: Source[] = [
  {
    id: 1,
    title: "NIS2 implementation in force",
    description:
      "Federal Office for Information Security, information on NIS2 registration and the entry into force of the German implementation act on 6 December 2025.",
    urls: [
      {
        label: "BSI NIS2 registration information",
        href: "https://mip2.bsi.bund.de/en/info-nis2-registrierung/",
      },
    ],
  },
  {
    id: 2,
    title: "Estimated number of affected German entities",
    description:
      "Federal Office for Information Security, NIS2 duties: approximately 29,500 particularly important and important entities face statutory obligations.",
    urls: [
      {
        label: "BSI NIS2 duties",
        href: "https://www.bsi.bund.de/DE/Themen/Regulierte-Wirtschaft/NIS-2-regulierte-Unternehmen/NIS-2-Pflichten/nis-2-pflichten_node.html",
      },
    ],
  },
  {
    id: 3,
    title: "Incident-reporting obligations",
    description: "German BSI Act, §32, with additional European Commission explanation.",
    urls: [
      {
        label: "German BSI Act §32",
        href: "https://www.gesetze-im-internet.de/bsig_2025/__32.html",
      },
      {
        label: "European Commission NIS2 FAQ",
        href: "https://digital-strategy.ec.europa.eu/en/faqs/directive-measures-high-common-level-cybersecurity-across-union-nis2-directive-faqs",
      },
    ],
  },
  {
    id: 4,
    title: "Management duties",
    description: "German BSI Act, §38.",
    urls: [
      {
        label: "German BSI Act §38",
        href: "https://www.gesetze-im-internet.de/bsig_2025/__38.html",
      },
    ],
  },
  {
    id: 5,
    title: "Machinery manufacturing as a listed sector",
    description: "German BSI Act, Annex 2.",
    urls: [
      {
        label: "German BSI Act Annex 2",
        href: "https://www.gesetze-im-internet.de/bsig_2025/anlage_2.html",
      },
    ],
  },
  {
    id: 6,
    title: "Entity thresholds and classification",
    description: "German BSI Act, §28.",
    urls: [
      {
        label: "German BSI Act §28",
        href: "https://www.gesetze-im-internet.de/bsig_2025/__28.html",
      },
    ],
  },
  {
    id: 7,
    title: "Cybersecurity risk-management measures",
    description: "German BSI Act, §30.",
    urls: [
      {
        label: "German BSI Act §30",
        href: "https://www.gesetze-im-internet.de/bsig_2025/__30.html",
      },
    ],
  },
  {
    id: 8,
    title: "Registration obligations",
    description: "German BSI Act, §33.",
    urls: [
      {
        label: "German BSI Act §33",
        href: "https://www.gesetze-im-internet.de/bsig_2025/__33.html",
      },
    ],
  },
];

export const additionalResources = [
  {
    label: "Official BSI applicability assessment",
    href: "https://betroffenheitspruefung-nis-2.bsi.de/",
  },
] as const;
