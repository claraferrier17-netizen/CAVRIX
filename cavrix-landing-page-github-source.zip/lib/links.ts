export type CtaLocation =
  | "hero"
  | "navigation"
  | "applicability"
  | "services"
  | "process"
  | "management"
  | "final"
  | "final_email";

const baseContactUrl = "https://www.cavrix.de/en/contact";
const campaignParams = {
  utm_source: "cavrix_case",
  utm_medium: "landing_page",
  utm_campaign: "nis2_machinery",
};

export function contactUrl(location: Exclude<CtaLocation, "final_email">) {
  const url = new URL(baseContactUrl);
  Object.entries(campaignParams).forEach(([key, value]) => {
    url.searchParams.set(key, value);
  });
  url.searchParams.set("utm_content", location);
  return url.toString();
}

export const assessmentEmailUrl =
  "mailto:info@cavrix.de?subject=NIS2%20assessment%20for%20a%20machinery%20manufacturer";

export const footerGroups = [
  {
    title: "Platform",
    links: [
      { label: "Managed IT", href: "https://www.cavrix.de/en/managed-it" },
      { label: "Cybersecurity", href: "https://www.cavrix.de/en/cybersecurity" },
      { label: "NIS2 compliance", href: "https://www.cavrix.de/en/nis2-compliance" },
      { label: "Command Center", href: "https://www.cavrix.de/en#command-center" },
    ],
  },
  {
    title: "Company",
    links: [
      { label: "About", href: "https://www.cavrix.de/en/about" },
      { label: "News", href: "https://www.cavrix.de/en/news" },
      { label: "Contact", href: "https://www.cavrix.de/en/contact" },
    ],
  },
  {
    title: "Trust and security",
    links: [
      { label: "Trust Center", href: "https://www.cavrix.de/en/trust-center" },
      { label: "Security", href: "https://www.cavrix.de/en/security" },
      { label: "AI and data", href: "https://www.cavrix.de/en/ai" },
    ],
  },
  {
    title: "Legal",
    links: [
      { label: "Privacy", href: "https://www.cavrix.de/en/privacy" },
      { label: "Imprint", href: "https://www.cavrix.de/en/imprint" },
    ],
  },
] as const;
