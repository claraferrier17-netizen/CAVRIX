import type { CtaLocation } from "@/lib/links";

export const navItems = [
  { label: "Why CAVRIX", href: "#why-cavrix" },
  { label: "NIS2 requirements", href: "#requirements" },
  { label: "How it works", href: "#how-it-works" },
  { label: "Sources", href: "#sources" },
] as const;

export const evidenceItems = [
  {
    label: "IN FORCE",
    value: "6 Dec 2025",
    text: "Germany's NIS2 implementation is already in force.",
    source: 1,
  },
  {
    label: "ESTIMATED SCOPE",
    value: "~29,500",
    text: "German entities face statutory NIS2 duties.",
    source: 2,
  },
  {
    label: "EARLY WARNING",
    value: "24 hours",
    text: "A significant incident may trigger an early-warning deadline.",
    source: 3,
  },
  {
    label: "GOVERNANCE",
    value: "Management",
    text: "Management must implement cybersecurity risk-management measures and monitor their implementation.",
    source: 4,
  },
] as const;

export const applicabilitySteps = [
  "Listed activity",
  "Employee or financial threshold",
  "Entity and group structure",
  "Statutory exceptions",
  "Individual assessment",
] as const;

export const industryRisks = [
  "Employee identities and access",
  "Workplace devices",
  "Microsoft 365 and collaboration",
  "ERP and order processing",
  "Remote maintenance access",
  "Backup and recovery",
] as const;

export const servicePillars = [
  {
    label: "01 / MANAGED IT",
    headline: "Keep critical business systems working.",
    items: [
      "Endpoint and identity management",
      "Patch and update management",
      "Microsoft 365 administration",
      "Backup and recovery processes",
      "Employee onboarding and offboarding",
      "IT support and documentation",
    ],
  },
  {
    label: "02 / CYBERSECURITY",
    headline: "Identify and address risk before it becomes disruption.",
    items: [
      "Security monitoring",
      "Vulnerability management",
      "Access control and multi-factor authentication",
      "Incident-response preparation",
      "Security awareness and training",
      "Risk-based remediation planning",
    ],
  },
  {
    label: "03 / COMPLIANCE EVIDENCE",
    headline: "Show what has actually been implemented.",
    items: [
      "Defined control ownership",
      "Policy and process documentation",
      "Implementation records",
      "Remediation tracking",
      "Management-ready reporting",
      "Structured evidence for reviews",
    ],
  },
] as const;

export const requirements = [
  {
    title: "Risk management",
    text: "Policies and processes for analysing cybersecurity risk and protecting network and information systems.",
  },
  {
    title: "Incident handling",
    text: "Defined processes for detecting, escalating, responding to and documenting security incidents.",
  },
  {
    title: "Business continuity",
    text: "Backup management, disaster recovery and crisis-management arrangements.",
  },
  {
    title: "Supply-chain security",
    text: "Consideration of risks connected to suppliers, service providers and direct business relationships.",
  },
  {
    title: "Vulnerability management",
    text: "Processes for identifying, assessing, disclosing and remediating vulnerabilities.",
  },
  {
    title: "People and access",
    text: "Cybersecurity training, access controls, asset management, secure authentication and appropriate use of encryption.",
  },
] as const;

export const processStages = [
  {
    number: "01",
    title: "Determine applicability",
    text: "Review the company's activity, size and structure to identify likely NIS2 applicability and questions requiring formal confirmation.",
    output: "Initial applicability assessment",
  },
  {
    number: "02",
    title: "Establish the baseline",
    text: "Map relevant systems, responsibilities, current controls, policies and available evidence.",
    output: "Current-state overview and gap assessment",
  },
  {
    number: "03",
    title: "Prioritise implementation",
    text: "Separate immediate risks from longer-term improvements and organise the work into a practical roadmap.",
    output: "Prioritised actions with owners and next steps",
  },
  {
    number: "04",
    title: "Operate and maintain",
    text: "Keep measures, documentation and evidence current as systems, staff, suppliers and risks change.",
    output: "Ongoing visibility and evidence maintenance",
  },
] as const;

export const managementQuestions = [
  "Which risks require immediate attention?",
  "Which measures have been implemented?",
  "Who owns each action?",
  "Which actions remain open?",
  "What evidence demonstrates implementation?",
  "What happens when a significant incident occurs?",
] as const;

export const incidentTimeline = [
  { label: "24 hours", text: "Early warning" },
  { label: "72 hours", text: "Incident notification" },
  { label: "Within one month after the 72-hour notification", text: "Final report, generally" },
] as const;

export const faqItems = [
  {
    question: "Is every machinery manufacturer with 50 or more employees covered by NIS2?",
    answer:
      "No. Machinery manufacturing is a listed sector and company size is an important criterion, but exact applicability depends on the company's activity, legal entity, financial data, structure and any relevant exceptions. An individual assessment is required.",
  },
  {
    question: "Does the assessment provide a legally binding classification?",
    answer:
      "No. The initial CAVRIX assessment is intended to identify likely applicability, relevant questions and practical next steps. It is not a substitute for formal legal advice.",
  },
  {
    question: "Can CAVRIX guarantee that my company is NIS2 compliant?",
    answer:
      "NIS2 compliance depends on the organisation's governance, systems, processes and continuing implementation. It cannot be guaranteed by installing one tool. CAVRIX can help assess gaps, implement measures, assign responsibilities and maintain evidence.",
  },
  {
    question: "Can we keep our existing IT provider?",
    answer:
      "CAVRIX can assess how an existing provider fits into the required operating model or discuss taking over defined responsibilities. Roles and accountability should be clearly documented.",
  },
  {
    question: "Does this include operational technology and industrial-control systems?",
    answer:
      "The initial assessment covers relevant IT, governance and compliance questions. Any specialist operational-technology or industrial-control-system scope must be identified and assessed separately before services or responsibilities are agreed.",
  },
  {
    question: "Is NIS2 already in force in Germany?",
    answer: "Yes. Germany's NIS2 implementation entered into force on 6 December 2025.",
    source: 1,
  },
  {
    question: "Do affected companies need to register?",
    answer:
      "Covered important and particularly important entities are generally required to register with the BSI no later than three months after they first or again qualify as a covered entity.",
    source: 8,
  },
] as const;

export const campaignAssets = [
  {
    title: "NIS2 does not end with IT.",
    file: "/campaign-assets/nis2-management-responsibility.svg",
    filename: "nis2-management-responsibility.svg",
    copy:
      "Cybersecurity is now a management responsibility. For covered entities, management must implement cybersecurity risk-management measures and monitor their implementation. CAVRIX helps machinery manufacturers connect IT operations, security measures and implementation evidence in one accountable model.",
    cta: "Check your likely applicability",
  },
  {
    title: "An unpatched system is not only an IT problem when production depends on it.",
    file: "/campaign-assets/production-risk.svg",
    filename: "production-risk.svg",
    copy:
      "When production depends on connected systems, cyber risk is operational risk. CAVRIX brings managed IT, cybersecurity and NIS2 evidence together for German machinery manufacturers.",
    cta: "Request a free assessment",
  },
] as const;

export type Cta = {
  label: string;
  location: CtaLocation;
};
