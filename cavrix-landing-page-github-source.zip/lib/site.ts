const configuredSiteUrl = process.env.NEXT_PUBLIC_SITE_URL;

export const siteUrl =
  configuredSiteUrl ?? (process.env.NODE_ENV === "development" ? "http://127.0.0.1:3000" : "https://www.cavrix.de");

export function absoluteUrl(path: string) {
  return new URL(path, siteUrl).toString();
}

export const landingPath = "/en/nis2-machinery";
