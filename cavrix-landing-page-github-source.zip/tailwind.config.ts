import type { Config } from "tailwindcss";

const config: Config = {
  content: [
    "./app/**/*.{js,ts,jsx,tsx,mdx}",
    "./components/**/*.{js,ts,jsx,tsx,mdx}",
    "./lib/**/*.{js,ts,jsx,tsx,mdx}",
  ],
  theme: {
    extend: {
      colors: {
        ink: "#090B0D",
        graphite: "#11151A",
        raised: "#171C22",
        paper: "#F3F5F2",
        muted: "#A8B0B5",
        accent: "#C8FF45",
        accentHover: "#D7FF78",
        line: "rgba(255,255,255,0.12)",
        danger: "#FF6B6B",
      },
      fontFamily: {
        sans: ["var(--font-sans)", "Inter", "system-ui", "sans-serif"],
        mono: ["var(--font-mono)", "ui-monospace", "SFMono-Regular", "monospace"],
      },
      boxShadow: {
        glow: "0 0 36px rgba(200, 255, 69, 0.24)",
        panel: "0 24px 80px rgba(0, 0, 0, 0.24)",
      },
      backgroundImage: {
        "industrial-grid":
          "linear-gradient(rgba(255,255,255,0.05) 1px, transparent 1px), linear-gradient(90deg, rgba(255,255,255,0.05) 1px, transparent 1px)",
      },
    },
  },
  plugins: [],
};

export default config;
