# CAVRIX NIS2 Machinery Landing Page

## What was built

A focused English conversion landing page for German machinery and equipment manufacturers that may be affected by NIS2.

The page is implemented as a standalone Next.js App Router project at `/`, with a non-indexed `/campaign-assets` preview route, two editable campaign SVGs in `public/campaign-assets/`, and a separate `1200 x 630` Open Graph SVG.

## Public page structure

The public page is intentionally limited to eight primary content sections:

1. Hero
2. Evidence and applicability
3. Production-risk problem
4. CAVRIX operating model
5. NIS2 requirements
6. Process
7. Management and incident readiness
8. FAQ, conversion and final CTA

Source notes and the footer remain outside that section count.

## Beachhead rationale

- Manufacture of machinery and equipment is listed in Annex 2 of the German BSI Act.
- The segment represents a clear German Mittelstand audience with practical IT, security and governance constraints.
- The buyer problem combines operational continuity, cybersecurity governance and implementation evidence.
- A vertical page is more specific than another general "NIS2 for SMEs" page because it reflects the production-supporting systems and management concerns of machinery manufacturers.

## Legal copy corrections

- Management-duty language follows §38 BSIG wording on implementing cybersecurity risk-management measures and monitoring their implementation.
- Applicability language states that machinery manufacturing is a listed sector under the German BSI Act, without implying automatic coverage.
- Registration language states that covered important and particularly important entities are generally required to register with the BSI no later than three months after they first or again qualify as covered entities.

## Conversion logic

1. Visitor recognises their industry.
2. Visitor understands NIS2 may apply.
3. Visitor connects cyber risk to production and management responsibility.
4. Visitor understands the integrated CAVRIX model.
5. Visitor requests a free assessment through the existing CAVRIX contact flow.

## Claim discipline

The page intentionally avoids:

- guaranteed compliance;
- automatic coverage claims;
- fake software functionality;
- fake customer data;
- fake testimonials;
- personal EUR 10 million fine claims;
- unverified OT-security promises.

## What is functional

- Sticky navigation with mobile menu and smooth internal scrolling.
- Responsive landing page at desktop, tablet and mobile widths.
- Crawlable source links and source-note anchors.
- Keyboard-operable FAQ accordion.
- Campaign-asset downloads through `/campaign-assets`.
- Outbound CTA links with campaign UTM parameters.
- Lightweight CTA click helper that safely pushes to `window.dataLayer` only when it exists.
- Live conversion through the existing English CAVRIX contact page and business email.

## What is illustrative

- The systems-map visual is an illustrative operating model.
- It is not a live product dashboard.
- No metrics displayed in it are customer data.

## Deployment

Local installation:

```bash
pnpm install
```

Environment:

```bash
cp .env.example .env.local
```

Set `NEXT_PUBLIC_SITE_URL` to the public site origin used for canonical, Open Graph and structured-data URLs. For the CAVRIX production site, use:

```bash
NEXT_PUBLIC_SITE_URL=https://www.cavrix.de
```

Development:

```bash
pnpm dev
```

Production build:

```bash
pnpm build
pnpm start
```

Vercel deployment:

```bash
pnpm install
pnpm build
vercel deploy
```

Production Vercel deployment:

```bash
vercel deploy --prod
```

Do not report Lighthouse scores unless they were actually measured in a suitable browser-testing environment. If browser-based testing is unavailable, report that as an unverified item instead of estimating scores.

Deployment from GitHub:

1. Push this repository to GitHub.
2. Create a Vercel project from the GitHub repository.
3. Keep the framework preset as Next.js.
4. Use `pnpm install` as the install command.
5. Use `pnpm build` as the build command.
6. Deploy the main branch.

## Sources

1. NIS2 implementation in force: Federal Office for Information Security, information on NIS2 registration and the entry into force of the German implementation act on 6 December 2025.  
   https://mip2.bsi.bund.de/en/info-nis2-registrierung/

2. Estimated number of affected German entities: Federal Office for Information Security, NIS2 duties.  
   https://www.bsi.bund.de/DE/Themen/Regulierte-Wirtschaft/NIS-2-regulierte-Unternehmen/NIS-2-Pflichten/nis-2-pflichten_node.html

3. Incident-reporting obligations: German BSI Act, §32.  
   https://www.gesetze-im-internet.de/bsig_2025/__32.html

   Additional European Commission explanation:  
   https://digital-strategy.ec.europa.eu/en/faqs/directive-measures-high-common-level-cybersecurity-across-union-nis2-directive-faqs

4. Management duties: German BSI Act, §38.  
   https://www.gesetze-im-internet.de/bsig_2025/__38.html

5. Machinery manufacturing as a listed sector: German BSI Act, Annex 2.  
   https://www.gesetze-im-internet.de/bsig_2025/anlage_2.html

6. Entity thresholds and classification: German BSI Act, §28.  
   https://www.gesetze-im-internet.de/bsig_2025/__28.html

7. Cybersecurity risk-management measures: German BSI Act, §30.  
   https://www.gesetze-im-internet.de/bsig_2025/__30.html

8. Registration obligations: German BSI Act, §33.  
   https://www.gesetze-im-internet.de/bsig_2025/__33.html

Additional resource: official BSI applicability assessment.  
https://betroffenheitspruefung-nis-2.bsi.de/
