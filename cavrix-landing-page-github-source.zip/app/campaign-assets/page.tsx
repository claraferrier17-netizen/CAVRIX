import type { Metadata } from "next";
import Image from "next/image";
import { Download } from "lucide-react";
import { campaignAssets } from "@/lib/content";

export const metadata: Metadata = {
  title: "Campaign Assets Preview | CAVRIX",
  robots: {
    index: false,
    follow: false,
  },
};

export default function CampaignAssetsPage() {
  return (
    <main className="min-h-screen bg-ink py-12 text-paper md:py-16">
      <div className="section-shell">
        <header className="max-w-3xl">
          <p className="eyebrow">Non-indexed preview</p>
          <h1 className="mt-4 text-4xl font-semibold leading-tight md:text-6xl">
            CAVRIX campaign assets
          </h1>
          <p className="mt-5 text-base leading-7 text-muted">
            Static SVG assets for the NIS2 machinery manufacturer campaign.
          </p>
        </header>

        <div className="mt-12 grid gap-12">
          {campaignAssets.map((asset) => (
            <article key={asset.filename} className="grid gap-6 rounded-lg border border-line bg-raised p-4 sm:p-6">
              <div className="flex flex-col justify-between gap-4 md:flex-row md:items-center">
                <div>
                  <h2 className="text-2xl font-semibold text-paper">{asset.title}</h2>
                  <p className="mt-2 font-mono text-xs text-muted">{asset.filename}</p>
                </div>
                <a
                  href={asset.file}
                  download={asset.filename}
                  className="inline-flex min-h-11 items-center justify-center gap-2 rounded-md border border-line bg-white/[0.04] px-4 py-2 text-sm font-semibold text-paper transition hover:bg-white/[0.08]"
                >
                  <Download aria-hidden="true" className="h-4 w-4" />
                  Download SVG
                </a>
              </div>

              <div className="grid gap-6 lg:grid-cols-[1fr_220px]">
                <div>
                  <p className="mb-3 font-mono text-[0.68rem] font-bold uppercase tracking-[0.14em] text-muted">
                    Desktop preview
                  </p>
                  <Image
                    src={asset.file}
                    alt={`${asset.title} desktop campaign asset preview`}
                    className="w-full rounded-md border border-line bg-ink"
                    width={1200}
                    height={628}
                    priority
                    unoptimized
                  />
                </div>
                <div>
                  <p className="mb-3 font-mono text-[0.68rem] font-bold uppercase tracking-[0.14em] text-muted">
                    Mobile-scaled preview
                  </p>
                  <Image
                    src={asset.file}
                    alt={`${asset.title} mobile-scaled campaign asset preview`}
                    className="w-full rounded-md border border-line bg-ink"
                    width={1200}
                    height={628}
                    unoptimized
                  />
                </div>
              </div>

              <div className="rounded-md border border-line bg-ink/72 p-4">
                <p className="font-mono text-[0.68rem] font-bold uppercase tracking-[0.14em] text-muted">
                  Ad copy
                </p>
                <p className="mt-3 max-w-4xl text-sm leading-7 text-muted">{asset.copy}</p>
                <p className="mt-4 text-sm font-semibold text-accent">{asset.cta}</p>
              </div>
            </article>
          ))}
        </div>
      </div>
    </main>
  );
}
