import { Applicability } from "@/components/applicability";
import { Faq } from "@/components/faq";
import { Footer } from "@/components/footer";
import { Hero } from "@/components/hero";
import { IncidentSection } from "@/components/incident-section";
import { IndustryProblem } from "@/components/industry-problem";
import { Navigation } from "@/components/navigation";
import { Process } from "@/components/process";
import { RequirementsGrid } from "@/components/requirements-grid";
import { ServicePillars } from "@/components/service-pillars";
import { SourceNotes } from "@/components/source-notes";
import { faqItems } from "@/lib/content";
import { absoluteUrl, landingPath } from "@/lib/site";

const organizationJsonLd = {
  "@context": "https://schema.org",
  "@type": "Organization",
  name: "CAVRIX",
  legalName: "CITO GmbH",
  url: absoluteUrl("/"),
  email: "info@cavrix.de",
  description:
    "CAVRIX is an AI-native managed IT, cybersecurity and compliance partner for the German Mittelstand.",
  areaServed: "DE",
  knowsAbout: ["Managed IT", "Cybersecurity", "NIS2 implementation", "Compliance evidence"],
};

const faqJsonLd = {
  "@context": "https://schema.org",
  "@type": "FAQPage",
  mainEntityOfPage: absoluteUrl(landingPath),
  mainEntity: faqItems.map((item) => ({
    "@type": "Question",
    name: item.question,
    acceptedAnswer: {
      "@type": "Answer",
      text: item.answer,
    },
  })),
};

export default function Home() {
  return (
    <>
      <Navigation />
      <main>
        <Hero />
        <Applicability />
        <IndustryProblem />
        <ServicePillars />
        <RequirementsGrid />
        <Process />
        <IncidentSection />
        <Faq />
        <SourceNotes />
      </main>
      <Footer />
      <script
        type="application/ld+json"
        dangerouslySetInnerHTML={{ __html: JSON.stringify(organizationJsonLd) }}
      />
      <script
        type="application/ld+json"
        dangerouslySetInnerHTML={{ __html: JSON.stringify(faqJsonLd) }}
      />
    </>
  );
}
