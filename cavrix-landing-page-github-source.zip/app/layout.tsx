import type { Metadata, Viewport } from "next";
import { Geist, Geist_Mono } from "next/font/google";
import { absoluteUrl, landingPath, siteUrl } from "@/lib/site";
import "./globals.css";

const geistSans = Geist({
  subsets: ["latin"],
  variable: "--font-sans",
  display: "swap",
});

const geistMono = Geist_Mono({
  subsets: ["latin"],
  variable: "--font-mono",
  display: "swap",
});

const title = "NIS2 Cybersecurity for German Machinery Manufacturers | CAVRIX";
const description =
  "Managed IT, cybersecurity and NIS2 implementation for German machinery manufacturers. Determine likely applicability, identify priority gaps and maintain clear evidence.";

export const metadata: Metadata = {
  metadataBase: new URL(siteUrl),
  title,
  description,
  applicationName: "CAVRIX",
  authors: [{ name: "CITO GmbH" }],
  alternates: {
    canonical: landingPath,
  },
  icons: {
    icon: "/favicon.svg",
  },
  openGraph: {
    title,
    description,
    url: absoluteUrl(landingPath),
    siteName: "CAVRIX",
    locale: "en_US",
    type: "website",
    images: [
      {
        url: "/campaign-assets/og-nis2-machinery.svg",
        width: 1200,
        height: 630,
        alt: "CAVRIX NIS2 campaign visual for machinery manufacturers",
      },
    ],
  },
  twitter: {
    card: "summary_large_image",
    title,
    description,
    images: ["/campaign-assets/og-nis2-machinery.svg"],
  },
};

export const viewport: Viewport = {
  width: "device-width",
  initialScale: 1,
  colorScheme: "dark",
  themeColor: "#090B0D",
};

export default function RootLayout({
  children,
}: Readonly<{
  children: React.ReactNode;
}>) {
  return (
    <html lang="en" className={`${geistSans.variable} ${geistMono.variable}`}>
      <body className="font-sans antialiased">{children}</body>
    </html>
  );
}
